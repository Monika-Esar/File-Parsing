import java.util.Scanner;

public class String_herna {
	
	public static void main(String args[]) {
		String c;
    	String data="{\\\"TrackPackagesRequest\\\":{\\\"appDeviceType\\\":\\\"DESKTOP\\\",\\\"appType\\\":\\\"WTRK\\\",\\\"processingParameters\\\":{},\\\"uniqueKey\\\":\\\"\\\",\\\"supportCurrentLocation\\\":true,\\\"supportHTML\\\":true,\\\"trackingInfoList\\\":[{\\\"trackNumberInfo\\\":{\\\"trackingNumber\\\":\\\"";
    			
    	String b="\\\",\\\"trackingQualifier\\\":null,\\\"trackingCarrier\\\":null}}]}}";
    	Scanner sc=new Scanner(System.in);
    	c=sc.nextLine();
    	String d= data+c+b;
    	System.out.println(d);
	}

}
