import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


import au.com.bytecode.opencsv.CSVReader; 
public class Training3csv_csvReader_Parser {
	public static void main(String[] args) {
		try(CSVReader reader = new CSVReader(new FileReader("C:\\\\\\\\Users\\\\\\\\KIIT\\\\\\\\Downloads\\\\\\\\Training(CSV)3.csv"))) {
			List<String> list=new ArrayList<String>();
		    int count=0;
		    int c=0;
		    String[] nextRow;
		   
		       while((nextRow = reader.readNext())!=null)
		       { 
		    	   List<String> l=Arrays.asList(nextRow);
		    	   if (l.contains("Ad Group"))
		    	   {
		         
		             	for(String headercell1:l ) {
		                	
		                    list.add(headercell1.replace(" ", "").toUpperCase());
		     
		                    }
		                    count++;
		                   System.out.println(list);
		            
		       }	
		    
		    	   else if(l.contains("TOTALS"))
		                {
		                    count--;
		                    continue;
		                }
		            else if(count>=1) {
		              
		            	System.out.print(nextRow[list.indexOf("ADGROUP")]+"\t");
                        System.out.print(nextRow[list.indexOf("DEAL#")]+"\t");
                        System.out.print(nextRow[list.indexOf("ITEM#")]+"\t");
                        System.out.print(nextRow[list.indexOf("UPC")]+"\t");
                        System.out.print(nextRow[list.indexOf("ALLOW.TYPE")]+"\t");
                        System.out.print(nextRow[list.indexOf("VENDORXREF")]+"\t");
                        System.out.print(nextRow[list.indexOf("DESC")]+"\t");
                        System.out.print(nextRow[list.indexOf("PACK")]+"\t");
                        System.out.print(nextRow[list.indexOf("SIZE")]+"\t");
                        System.out.print(nextRow[list.indexOf("DEAL#")]+"\t");
                        System.out.print(nextRow[list.indexOf("STORE#")]+"\t");
                        System.out.print(nextRow[list.indexOf("STARTDATE")]+"\t");
                        System.out.print(nextRow[list.indexOf("ENDDATE")]+"\t");
                        System.out.print(nextRow[list.indexOf("DEALAMT")]+"\t");
                        System.out.print(nextRow[list.indexOf("MOVEMENT")]+"\t");
                        System.out.print(nextRow[list.indexOf("EXTENDEDDEALAMOUNT")]+"\t");
                        System.out.print(nextRow[list.indexOf("EXTENDEDCONTRACTFEE")]+"\t");
                        System.out.print(nextRow[list.indexOf("TOTALOFEXTENDED")]+"\t");
                  
                        System.out.println();
		                
		                
		                c++;
		            }
		            
		                
		                
		             	
		       }
		        System.out.println("total item level data:"+c);
		    } catch (IOException e) {
		   // TODO Auto-generated catch block
		   e.printStackTrace();
		}
	       

		}
}
