import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excelaafai {
	public static void main(String[] args) {
		XSSFSheet workSheet = null;
		XSSFWorkbook wbxlsx;
		Row row;
		XSSFCell cell;
		int rowNo,i,k=0,flag=0,RowIndex=0;
		try {
			FileInputStream fis = new FileInputStream(new File("C:\\Users\\KIIT\\Downloads\\Telegram Desktop\\Training2(XLSX).xlsx"));
			wbxlsx = new XSSFWorkbook(fis);

			if(wbxlsx != null){
				workSheet = wbxlsx.getSheetAt(0);

				rowNo=workSheet.getLastRowNum();
				while(k<rowNo)
				{
					row=workSheet.getRow(k);
					if(row!=null)
					{
						for(i=0;i< workSheet.getRow(k).getLastCellNum();i++)
						{
							cell=workSheet.getRow(k).getCell(i);
							if(cell!=null)
							{
								String s=cell.toString();
								if(s.equals("VENDOR CODE"))//Ref. Number
								{
									flag=1;
									break;
								}
							}
						}
					}
					

					if(flag==1)
					{
						RowIndex=k;
						break;
					}
					k++;
				}

				List<String> headerList = prepareXlsHeaderList(workSheet, RowIndex);
				System.out.println(headerList);
				for (rowNo = RowIndex+1; rowNo < workSheet.getLastRowNum(); rowNo++) {
					row = workSheet.getRow(rowNo);
					
					if(row!=null) {
						
						for(String temp:headerList) {
							cell = workSheet.getRow(rowNo).getCell((short) headerList.indexOf(temp));
							System.out.print(cell.toString()+"\t");
						}
						
					}
					System.out.println();
				}
			} 
		}catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private static List<String> prepareXlsHeaderList(XSSFSheet workSheet, int index) {
		List<String> headersList = new ArrayList<String>();
		for (int cell = 0; cell < workSheet.getRow(index).getLastCellNum(); cell++) {
			XSSFCell hcell = workSheet.getRow(index).getCell((short) cell);
			headersList.add(null!=hcell?hcell.getRichStringCellValue().toString().toUpperCase().replaceAll(" ", ""):"");
		}
		return headersList;
	}


}
