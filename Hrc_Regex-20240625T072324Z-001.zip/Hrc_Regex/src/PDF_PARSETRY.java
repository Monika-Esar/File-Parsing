import java.util.regex.*; 
import java.io.*;

public class PDF_PARSETRY {
	public static String readFile(String file) throws Exception{
		
		 BufferedReader br = new BufferedReader(new FileReader(file));
		 try {
			 StringBuilder sb = new StringBuilder();
			 String line = null;
			 while((line = br.readLine()) != null) {
				 sb.append(line);
				
			 }
			 sb.deleteCharAt(sb.length()-1);
			 return sb.toString();
		 }finally {
			 br.close();
		 }
		 }
		
		
		
		public static void header(String line) {
			
			String pattern ="Ship\\s*To\\s*:\\s*([\\w\\s]*[^P]*).*?Payable\\s*to\\s*:\\s*([\\w]*\\s*[\\w]*\\s*[\\w]*)\\s*.*?Mail-to\\s*:(\\s*[\\w]*\\s*[\\w]*\\s*[\\w]*)\\s*.*?Payer\\s*:(\\s*[\\w]*\\s*[\\w]*\\s*[\\w]*.[\\w]*\\s*[\\w]*.[\\w]*)\\s*([\\w]*\\s*[\\w]*\\s*[\\w]*)\\s*([\\w]*\\s*[\\w]*\\s*[\\w]*\\s*[\\w\\s]*.[\\w]*)\\s*";
			Pattern r=Pattern.compile(pattern);
			Matcher m=r.matcher(line);
			boolean found = false; 
			
			System.out.println("######Headerlevel_Data:#########\n");
			while(m.find()) {
				//int n=1;
				//while(n<8) {
				System.out.println("Header Value:"+m.group(3)+m.group(5));
				//n=n+1;
				//}
				found = true; 
			}
			if(!found){
				System.out.println("No");
			}
		}
		
		public static void itemlevel(String line) {
			
			 String pattern = "Ship\\s*To\\s*:\\s*([\\w\\s]*[^P]*).*?Payable\\s*to\\s*:\\s*([\\w]*\\s*[\\w]*\\s*[\\w]*)\\s*.*?Mail-to\\s*:(\\s*[\\w]*\\s*[\\w]*\\s*[\\w]*)\\s*.*?Payer\\s*:(\\s*[\\w]*\\s*[\\w]*\\s*[\\w]*.[\\w]*\\s*[\\w]*.[\\w]*)\\s*([\\w]*\\s*[\\w]*\\s*[\\w]*)\\s*([\\w]*\\s*[\\w]*\\s*[\\w]*\\s*[\\w\\s]*.[\\w]*)\\s*";
				Pattern r=Pattern.compile(pattern);
				Matcher m=r.matcher(line);
				boolean found = false; 
				
				System.out.println("\n######Itemlevel_Data:#########\n");
				while(m.find()) {
					
				System.out.println("Item level Value:"+m.group(1));
				 found = true; 
				}
				if(!found){
					System.out.println("No");
				}
			
		}

		public static void main(String[] args)throws Exception
		  {
			 String line = readFile("C:\\\\\\\\Users\\\\\\\\KIIT\\\\\\\\Downloads\\\\\\\\trainingpdf.txt");
			 header(line);
			 itemlevel(line);
			}
}
