import java.util.regex.*; 
public class htmlko {
	
	public static void main(String args[]){  
		String line="<script>\r\n" + 
				"function validar(e) { // 1\r\n" + 
				"� � tecla = (document.all) ? e.keyCode : e.which; // 2\r\n" + 
				"� � if (tecla==8) return true; // 3\r\n" + 
				"� � patron =/[0-9]/; // 4\r\n" + 
				"� � te = String.fromCharCode(tecla); // 5\r\n" + 
				"� � return patron.test(te); // 6\r\n" + 
				"}�\r\n" + 
				"</script>\r\n" + 
				"\r\n" + 
				"09/Jun/2020*1,217.45*A0049*108846� � � � � � � *7765635<table border=0 cellspacing=0 cellpadding=0 width=\"850\" align=\"Center\">\r\n" + 
				"<tr>\r\n" + 
				"<td align=\"Left\" width=\"70\"><img src=\"disenio/logo130.jpg\" Align=\"center\"></td>\r\n" + 
				"<td align=\"Right\" width=\"780\"><img src=\"http://www.abz.com.mx/imagenes/A0049.gif\"></td>\r\n" + 
				"</tr>\r\n" + 
				"<tr>\r\n" + 
				"<td colspan=\"2\" align=\"Center\"><H1>Comprobante de Pago </H1></td>\r\n" + 
				"<tr>\r\n" + 
				"</table>\r\n" + 
				"<HR Size \"3\" Width=\"850\" Align = \"Center\" NoShade = \"NOSHADE\">\r\n" + 
				"<HR Size \"3\" Width=\"850\" Align = \"Center\" NoShade = \"NOSHADE\">\r\n" + 
				"<table border=0 cellspacing=0 cellpadding=0 width=\"850\" align=\"center\">\r\n" + 
				"<tr> \r\n" + 
				"<td align=\"Left\" width=\"100\"> <b>Fecha :</b></td>\r\n" + 
				"<td align=\"Left\" width=\"750\"> 09/Jun/2020 </td>\r\n" + 
				"</tr>\r\n" + 
				"<tr> \r\n" + 
				"<td align=\"Left\" width=\"100\"> <b>Validado por : </b></td>\r\n" + 
				"<td align=\"Left\" width=\"550\"> BANCO SANTANDER MEXICANO, S.A.� � � � � �</td>\r\n" + 
				"<td align=\"right\" width=\"200\">\r\n" + 
				"<table border=0 cellspacing=0 cellpassing=0 width=\"200\" align=\"right\">\r\n" + 
				"� <tr>\r\n" + 
				"<td align=\"right\"><b>Importe</b> :� � <b>1,217.45</b> </td>\r\n" + 
				"� </tr>\r\n" + 
				"</table>\r\n" + 
				"</td> \r\n" + 
				"</tr>\r\n" + 
				"<tr>\r\n" + 
				"<td align=\"Left\" width=\"100\"> <b>Cta. Abono : </b> </td>\r\n" + 
				"<td align=\"Left\" width=\"750\">� </td>\r\n" + 
				"</tr>\r\n" + 
				"<tr> \r\n" + 
				"<td align=\"Left\" width=\"100\"> <b>Autorizacion : </b></td>\r\n" + 
				"<td align=\"Left\" width=\"750\"> 7765635 </td>\r\n" + 
				"</tr>\r\n" + 
				"<tr>� � \r\n" + 
				"<td align=\"Left\" width=\"100\"> <b>Proveedor : </b></td>\r\n" + 
				"<td align=\"Left\" width=\"750\"> 007138&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td> \r\n" + 
				"</tr>\r\n" + 
				"<tr> \r\n" + 
				"<td align=\"Left\" width=\"100\"> <b>Referencia : </b></td>\r\n" + 
				"<td align=\"Left\" width=\"750\"> Pago Docto. No. 887917� � � � � � � �</td>�\r\n" + 
				"</tr>\r\n" + 
				"</table>\r\n" + 
				"<HR Size \"3\" Width=\"850\" Align = \"Center\" NoShade = \"NOSHADE\">\r\n" + 
				"<table align=\"center\" border=0 cellspacing=0 cellpadding=0 width=\"850\">\r\n" + 
				"<tr>\r\n" + 
				"<td align=\"Center\" width=\"70\"> <b>Codigo</b> </td>\r\n" + 
				"<td align=\"Right\" width=\"70\"> <b>P.Lista</b> </td>\r\n" + 
				"<td align=\"Center\" width=\"90\"> <b>S/Cargo</b> </td>\r\n" + 
				"<td align=\"Right\" width=\"42\"><b> Ds.1 </b></td>\r\n" + 
				"<td align=\"Right\" width=\"52\"> <b>Ds.2</b> </td>\r\n" + 
				"<td align=\"Right\" width=\"52\"> <b>Ds.3</b> </td>\r\n" + 
				"<td align=\"Right\" width=\"52\"> <b>Ds.4</b> </td>\r\n" + 
				"<td align=\"Right\" width=\"52\"> <b>Ds.5</b> </td>\r\n" + 
				"<td align=\"Right\" width=\"90\"> <b>Costo</b> </td>\r\n" + 
				"<td align=\"Right\" width=\"80\"> <b>Cantid.</b> </td>\r\n" + 
				"<td align=\"Right\" width=\"100\"> <b>Total</b> </td>\r\n" + 
				"<td align=\"Center\" width=\"100\"> <b>Pedido</b> </td>\r\n" + 
				"</tr><tr>\r\n" + 
				"<td align=\"Left\" colspan=\"5\" width=\"304\"><font size=\"2\"> PILA DURACELL AA TIRA� � � � � � � � � � � � � � � � � � � � </font></td>\r\n" + 
				"<td align=\"Left\" colspan=\"8\" width=\"596\"><font size=\"2\">� � 6 PZ� � </font></td>\r\n" + 
				"</tr>\r\n" + 
				"<tr>\r\n" + 
				"<td align=\"Center\" width=\"70\"><font size=\"2\"> 060224� � � � � � � � � � � � �</font></td>\r\n" + 
				"<td align=\"Right\" width=\"70\"><font size=\"2\"> 1,399.93 </font></td>\r\n" + 
				"<td align=\"Center\" width=\"90\"><font size=\"2\"> 0/0 </font></td>\r\n" + 
				"<td align=\"Right\" width=\"42\"><font size=\"2\"> 0.00 </font></td>\r\n" + 
				"<td align=\"Right\" width=\"52\"><font size=\"2\"> 0.00 </font></td>\r\n" + 
				"<td align=\"Right\" width=\"52\"><font size=\"2\"> 0.00 </font></td>\r\n" + 
				"<td align=\"Right\" width=\"52\"><font size=\"2\"> 0.00 </font></td>\r\n" + 
				"<td align=\"Right\" width=\"52\"><font size=\"2\"> 0.00 </font></td>\r\n" + 
				"<td align=\"Right\" width=\"90\"><font size=\"2\"> 1,392.93 </td>\r\n" + 
				"<td align=\"Right\" width=\"80\"><font size=\"2\"> 60.0 </font></td>\r\n" + 
				"<td align=\"Right\" width=\"100\"><font size=\"2\">$ 60.00 </font></td>\r\n" + 
				"<td align=\"Center\" width=\"100\"><font size=\"2\"> 355152 </font></td>\r\n" + 
				"</tr><tr>\r\n" + 
				"<td align=\"Left\" colspan=\"5\" width=\"304\"><font size=\"2\"> PILA DURACELL AAA TIRA� � � � � � � � � � � � � � � � � � � �</font></td>\r\n" + 
				"<td align=\"Left\" colspan=\"8\" width=\"596\"><font size=\"2\">� � 6 PZ� � </font></td>\r\n" + 
				"</tr>\r\n" + 
				"<tr>\r\n" + 
				"<td align=\"Center\" width=\"70\"><font size=\"2\"> 060225� � � � � � � � � � � � �</font></td>\r\n" + 
				"<td align=\"Right\" width=\"70\"><font size=\"2\"> 764.13 </font></td>\r\n" + 
				"<td align=\"Center\" width=\"90\"><font size=\"2\"> 0/0 </font></td>\r\n" + 
				"<td align=\"Right\" width=\"42\"><font size=\"2\"> 0.00 </font></td>\r\n" + 
				"<td align=\"Right\" width=\"52\"><font size=\"2\"> 0.00 </font></td>\r\n" + 
				"<td align=\"Right\" width=\"52\"><font size=\"2\"> 0.00 </font></td>\r\n" + 
				"<td align=\"Right\" width=\"52\"><font size=\"2\"> 0.00 </font></td>\r\n" + 
				"<td align=\"Right\" width=\"52\"><font size=\"2\"> 0.00 </font></td>\r\n" + 
				"<td align=\"Right\" width=\"90\"><font size=\"2\"> 760.31 </td>\r\n" + 
				"<td align=\"Right\" width=\"80\"><font size=\"2\"> 40.0 </font></td>\r\n" + 
				"<td align=\"Right\" width=\"100\"><font size=\"2\">$ 30,412.40 </font></td>\r\n" + 
				"<td align=\"Center\" width=\"100\"><font size=\"2\"> 355152 </font></td>\r\n" + 
				"</tr><tr>\r\n" + 
				"<td align=\"Left\" colspan=\"5\" width=\"304\"><font size=\"2\"> TARIMAS CHEP� �1/� �1 UD� � � � � � � � � � � � � � � � � � �</font></td>\r\n" + 
				"<td align=\"Left\" colspan=\"8\" width=\"596\"><font size=\"2\">� � 1 UD� � </font></td>\r\n" + 
				"</tr>\r\n" + 
				"<tr>\r\n" + 
				"<td align=\"Center\" width=\"70\"><font size=\"2\"> 900001� � � � � � � � � � � � �</font></td>\r\n" + 
				"<td align=\"Right\" width=\"70\"><font size=\"2\"> 0.01 </font></td>\r\n" + 
				"<td align=\"Center\" width=\"90\"><font size=\"2\"> 0/0 </font></td>\r\n" + 
				"<td align=\"Right\" width=\"42\"><font size=\"2\"> 0.00 </font></td>\r\n" + 
				"<td align=\"Right\" width=\"52\"><font size=\"2\"> 0.00 </font></td>\r\n" + 
				"<td align=\"Right\" width=\"52\"><font size=\"2\"> 0.00 </font></td>\r\n" + 
				"<td align=\"Right\" width=\"52\"><font size=\"2\"> 0.00 </font></td>\r\n" + 
				"<td align=\"Right\" width=\"52\"><font size=\"2\"> 0.00 </font></td>\r\n" + 
				"<td align=\"Right\" width=\"90\"><font size=\"2\"> 0.01 </td>\r\n" + 
				"<td align=\"Right\" width=\"80\"><font size=\"2\"> 1.0 </font></td>\r\n" + 
				"<td align=\"Right\" width=\"100\"><font size=\"2\">$ 0.01 </font></td>\r\n" + 
				"<td align=\"Center\" width=\"100\"><font size=\"2\"> 353873 </font></td>\r\n" + 
				"</tr><tr>\r\n" + 
				"<td colspan=\"12\"><HR Size \"3\" Width=\"850\" Align = \"Center\" NoShade = \"NOSHADE\"></td>\r\n" + 
				"</tr>\r\n" + 
				"<tr>\r\n" + 
				"<td align=\"Center\" width=\"140\" colspan=\"2\"> <b>Totales : </td>\r\n" + 
				"<td align=\"Left\" width=\"236\" colspan=\"4\">- $ 30,625.21 </td>\r\n" + 
				"<td align=\"Center\" width=\"194\" colspan=\"3\">$ -83,363.00 </td>\r\n" + 
				"<td align=\"Center\" width=\"80\"> 101 </td>\r\n" + 
				"<td align=\"Right\" width=\"100\">$ 113,988.21 </td>\r\n" + 
				"<td align=\"Center\" width=\"100\">&nbsp;</td>\r\n" + 
				"</tr>\r\n" + 
				"<tr>\r\n" + 
				"<td align=\"Center\" width=\"570\" colspan=\"9\">&nbsp;</font></td>\r\n" + 
				"<td align=\"Center\" width=\"80\"> <b>I.V.A. :</b> </td>\r\n" + 
				"<td� align=\"Right\" width=\"100\">$ 18,238.11 </td>\r\n" + 
				"<td align=\"Center\" width=\"100\">&nbsp;</td>\r\n" + 
				"</tr>\r\n" + 
				"<tr>\r\n" + 
				"<td align=\"Center\" width=\"570\" colspan=\"9\">&nbsp;</font></td>\r\n" + 
				"<td align=\"Center\" width=\"80\"> <b>Total :</b> </td>\r\n" + 
				"<td� align=\"Right\" width=\"100\">$ 132,226.32 </td>\r\n" + 
				"<td align=\"Center\" width=\"100\">&nbsp;</td>\r\n" + 
				"</tr>\r\n" + 
				"<tr>\r\n" + 
				"<td align=\"Center\" width=\"140\" colspan=\"2\"> 06/05/2020 </td>\r\n" + 
				"<td align=\"Left\" width=\"236\" colspan=\"4\">- DSCTO.PLAN MENSUAL� </td>\r\n" + 
				"<td align=\"Center\" width=\"194\" colspan=\"3\"> 0147933� � � � � � � </td>\r\n" + 
				"<td align=\"Center\" width=\"80\">&nbsp;</td>\r\n" + 
				"<td align=\"Right\" width=\"100\">120,430.76</td>\r\n" + 
				"<td align=\"Center\" width=\"100\">&nbsp;</td>\r\n" + 
				"</tr>\r\n" + 
				"<tr>\r\n" + 
				"<td align=\"Center\" width=\"140\" colspan=\"2\"> - </td>\r\n" + 
				"<td align=\"Left\" width=\"236\" colspan=\"4\"> Prm. 113572 NAC.DA. SELL OUT M Correpondiente� a 202005� � � �Cobro Automatico 05/06/2020� � 01/05/2020 Al 31/05/2020� � � �</td>\r\n" + 
				"<td align=\"Center\" width=\"100\">&nbsp;</td>\r\n" + 
				"</tr>\r\n" + 
				"<tr>\r\n" + 
				"<td align=\"Center\" width=\"140\" colspan=\"2\"> 06/09/2020 </td>\r\n" + 
				"<td align=\"Left\" width=\"236\" colspan=\"4\">- PAGO SANTANDER 7304 </td>\r\n" + 
				"<td align=\"Center\" width=\"194\" colspan=\"3\"> 108846� � � � � � � �</td>\r\n" + 
				"<td align=\"Center\" width=\"80\">&nbsp;</td>\r\n" + 
				"<td align=\"Right\" width=\"100\">1,217.45</td>\r\n" + 
				"<td align=\"Center\" width=\"100\">&nbsp;</td>\r\n" + 
				"</tr>\r\n" + 
				"<tr>\r\n" + 
				"<td align=\"Center\" width=\"140\" colspan=\"2\"> - </td>\r\n" + 
				"<td align=\"Left\" width=\"236\" colspan=\"4\"> Pago Via Electronica.� � � � � C0001 887917� � � � � � � � � � �</td>\r\n" + 
				"<td align=\"Center\" width=\"100\">&nbsp;</td>\r\n" + 
				"</tr>\r\n" + 
				"<tr>\r\n" + 
				"<td align=\"Center\" width=\"140\" colspan=\"2\"> 06/09/2020 </td>\r\n" + 
				"<td align=\"Left\" width=\"236\" colspan=\"4\">- DESC.FINANCIEROS� � </td>\r\n" + 
				"<td align=\"Center\" width=\"194\" colspan=\"3\"> 96660� � � � � � � � </td>\r\n" + 
				"<td align=\"Center\" width=\"80\">&nbsp;</td>\r\n" + 
				"<td align=\"Right\" width=\"100\">10,578.11</td>\r\n" + 
				"<td align=\"Center\" width=\"100\">&nbsp;</td>\r\n" + 
				"</tr>\r\n" + 
				"<tr>\r\n" + 
				"<td align=\"Center\" width=\"140\" colspan=\"2\"> - </td>\r\n" + 
				"<td align=\"Left\" width=\"236\" colspan=\"4\"> Descto.Por Pronto Pago� � � � �C0001 887917� � � � � � � � � � �</td>\r\n" + 
				"<td align=\"Center\" width=\"100\">&nbsp;</td>\r\n" + 
				"</tr><tr>\r\n" + 
				"<td colspan=\"12\"><A HREF=\"mailto:eescalera@abz.com.mx\"> Dudas o Aclaraciones. </A></td>\r\n" + 
				"</tr>\r\n" + 
				"</table>";
				
		//String pattern = "<td\\s*align=[^\"]*\"[^\"]*\"\\s*colspan=\"[^>]*>[^>]*>\\s*([^<]+)[^>]*>[^>]*>[^>]*>[^>]*>([^<]+)<[^<]*<[^<]*<[^<]*<[^<]*<[^>]*>[^>]*>([^<]*)<[^>]*>[^>]*>[^>]*>[^>]*>([^<]*)<[^<]*<[^>]*>[^>]*>[^>]*>([^<]*)<[^<]*<[^>]*>[^>]*>[^>]*>([^<]*)<[^<]*<[^>]*>[^>]*>[^>]*>([^<]*)<[^<]*<[^>]*>[^>]*>[^>]*>([^<]*)<[^<]*<[^>]*>[^>]*>[^>]*>([^<]*)<[^<]*<[^>]*>[^>]*>[^>]*>([^<]*)<[^<]*<[^>]*>[^>]*>[^>]*>([^<]*)<[^>]*>[^>]*>[^>]*>([^<]*)<[^<]*<[^>]*>[^>]*>[^>]*>([^<]*)<[^<]*<[^>]*>[^>]*>[^>]*>([^<]*)<[^<]*<[^>]*>";
		String pattern = "<td\\s*align=[^\"]*\"[^\"]*\"\\s*[^>]*><font\\s*size=\\s*[^\"]*\"[^\"]*\">([^<]*)<[^<]*";
		Pattern r=Pattern.compile(pattern);
		
		Matcher m=r.matcher(line);
		boolean found = false; 
		
		
		while(m.find()) {
			//int n=1;
			//System.out.println("Value:"+m.group(1)+m.group(2)+m.group(3)+m.group(4));
			//while(n<15) {
				System.out.println("Value:"+m.group(1));
				//n=n+1;
			//}
			//System.out.println("\n");
			found = true; 
		}
		if(!found){
			System.out.println("No");
		}
	}
	
}
