import java.io.BufferedReader;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpOptions;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import com.sun.xml.txw2.Document;

public class Navigation_Java_Handson {
	public static void main(String[] args) {
        HttpClient client = HttpClients.createDefault();
        
        HttpGet httpget = new HttpGet("https://www.fedex.com/en-us/home.html");
                    
        HttpPost post = new HttpPost("https://www.fedex.com/trackingCal/track");
        
        HttpGet post1 = new HttpGet("https://www.fedex.com/trackingCal/retrievePDF.jsp?accountNbr=&anon=true&appType=&destCountry=&locale=en_US&shipDate=&trackingCarrier=FDXG&trackingNumber=941829330934&trackingQualifier=12021~941829330934~FDEG&type=SPOD");
        try {
        	//Printing the method used
      		System.out.println("Request Type: "+httpget.getMethod());
      		
      		//Executing the Get request
      		HttpResponse httpresponse = client.execute(httpget);
      		
      		System.out.println("get method");
      		 // Get HttpResponse Status
              System.out.println(httpresponse.getProtocolVersion());              // HTTP/1.1
              System.out.println(httpresponse.getStatusLine().getStatusCode());   // 200
              System.out.println(httpresponse.getStatusLine().getReasonPhrase()); // OK
              System.out.println(httpresponse.getStatusLine().toString());     
              
              HttpEntity entity = httpresponse.getEntity();
              if (entity != null) {
                  // return it as a String
                  String result = EntityUtils.toString(entity);
                  System.out.println(result);
              }//"\\\"941829330934\\\""
            
        	String c;
        	String data="{\\\"TrackPackagesRequest\\\":{\\\"appDeviceType\\\":\\\"DESKTOP\\\",\\\"appType\\\":\\\"WTRK\\\",\\\"processingParameters\\\":{},\\\"uniqueKey\\\":\\\"\\\",\\\"supportCurrentLocation\\\":true,\\\"supportHTML\\\":true,\\\"trackingInfoList\\\":[{\\\"trackNumberInfo\\\":{\\\"trackingNumber\\\":\\\"";
        			
        	String b="\\\",\\\"trackingQualifier\\\":null,\\\"trackingCarrier\\\":null}}]}}";
        	Scanner sc=new Scanner(System.in);
        	System.out.println("Enter tracking number:");
        	c=sc.nextLine();
        	String d= data+c+b;		
        	String d1="{\\\"TrackPackagesRequest\\\":{\\\"appDeviceType\\\":\\\"DESKTOP\\\",\\\"appType\\\":\\\"WTRK\\\",\\\"processingParameters\\\":{},\\\"uniqueKey\\\":\\\"\\\",\\\"supportCurrentLocation\\\":true,\\\"supportHTML\\\":true,\\\"trackingInfoList\\\":[{\\\"trackNumberInfo\\\":{\\\"trackingNumber\\\":\\\"941829330934\\\",\\\"trackingQualifier\\\":null,\\\"trackingCarrier\\\":null}}]}}";
            List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
            nameValuePairs.add(new BasicNameValuePair("action","trackpackages"));
            nameValuePairs.add(new BasicNameValuePair("data","{\"TrackPackagesRequest\":{\"appDeviceType\":\"DESKTOP\",\"appType\":\"WTRK\",\"processingParameters\":{},\"uniqueKey\":\"\",\"supportCurrentLocation\":true,\"supportHTML\":true,\"trackingInfoList\":[{\"trackNumberInfo\":{\"trackingNumber\":\"941829330934\",\"trackingQualifier\":null,\"trackingCarrier\":null}}]}}"));
          //  nameValuePairs.add(new BasicNameValuePair("data",d1));
            nameValuePairs.add(new BasicNameValuePair("format","json"));
            nameValuePairs.add(new BasicNameValuePair("locale","en_US"));
            nameValuePairs.add(new BasicNameValuePair("version","1"));
            
            post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
            // send a JSON data post.setEntity(new StringEntity(entity.toString()));
            
            HttpResponse response = client.execute(post);
            
            System.out.println("post method");
    		//Printing the status line
    		System.out.println(response.getProtocolVersion());              // HTTP/1.1
            System.out.println(response.getStatusLine().getStatusCode());   // 200
            System.out.println(response.getStatusLine().getReasonPhrase()); // OK
            System.out.println(response.getStatusLine().toString());        // HTTP/1.1 200 OK

           /* BufferedReader rd = new BufferedReader(new InputStreamReader(
                    response.getEntity().getContent()));
            String line = "";
            while ((line = rd.readLine()) != null) {
                System.out.println(line);
            }*/
           /* Scanner sc = new Scanner(response.getEntity().getContent());
    		while(sc.hasNext()) {
    			System.out.println(sc.nextLine());
    		}*/
            StringBuilder sb = new StringBuilder();
            HttpEntity entity1 = response.getEntity();
            if (entity1 != null) {
                // return it as a String
                String result = EntityUtils.toString(entity1);
                sb.append(result);
               // System.out.println(result);
            }
            FileWriter fstream = new FileWriter("fedex.html");
            BufferedWriter out = new BufferedWriter(fstream);
            out.write(sb.toString());
            out.close();

            
        /*    List<NameValuePair> nameValuePairs1 = new ArrayList<NameValuePair>();
            nameValuePairs1.add(new BasicNameValuePair("action","getTrackingProfile"));
            nameValuePairs1.add(new BasicNameValuePair("data","{\"TrackingProfileRequest\":{\"appDeviceType\":\"DESKTOP\",\"appType\":\"WTRK\",\"processingParameters\":{},\"uniqueKey\":\"\"}}"));
            nameValuePairs1.add(new BasicNameValuePair("format","json"));
            nameValuePairs1.add(new BasicNameValuePair("locale","en_US"));
            nameValuePairs1.add(new BasicNameValuePair("version","1"));
            
            post1.setEntity(new UrlEncodedFormEntity(nameValuePairs1));*/
            // send a JSON data post.setEntity(new StringEntity(entity.toString()));
            
            HttpResponse response1 = client.execute(post1);
            
            System.out.println("post method");
    		//Printing the status line
    		System.out.println(response1.getProtocolVersion());              // HTTP/1.1
            System.out.println(response1.getStatusLine().getStatusCode());   // 200
            System.out.println(response1.getStatusLine().getReasonPhrase()); // OK
            System.out.println(response1.getStatusLine().toString());        // HTTP/1.1 200 OK
            
            StringBuilder sb1= new StringBuilder();
            HttpEntity entity2 = response1.getEntity();
            if (entity2 != null) {
                // return it as a String
                String result = EntityUtils.toString(entity2);
                sb1.append(result);
               // System.out.println(result);
            }
            FileWriter fstream1 = new FileWriter("fedex1.pdf");
            BufferedWriter out1 = new BufferedWriter(fstream1);
            out1.write(sb1.toString());
            out1.close();
             

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
	
	
}
