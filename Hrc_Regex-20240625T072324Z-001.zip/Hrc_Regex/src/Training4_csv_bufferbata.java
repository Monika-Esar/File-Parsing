import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.*;

public class Training4_csv_bufferbata {
	public static void main(String[] args) {
		List<String> list = new ArrayList<String>();
		List<String> list1 = new ArrayList<String>();
		String csvFile = "C:\\\\Users\\\\KIIT\\\\Downloads\\\\Training(CSV)4.csv";
		String pattern ="[^\"]*(\"[^\"]*\")";
		Pattern r=Pattern.compile(pattern);
		String[] header,nextRow;
		String line;
	    int c=0;
	    try(BufferedReader reader = new BufferedReader(new FileReader(csvFile))) {
	    	line = reader.readLine();
	    	Matcher m=r.matcher(line);
	    	while(line != null) {
	        	if(line.contains("Date")){
	        		header =line.split(",");
	        		   for (String headercell:header) {
	       	        	list.add(headercell.replace(" ", "").toUpperCase());
	       	        	
	       	        }
	       	       // System.out.println(list);
	       	        c++;
	       	      
	        	}else if(m.find()){
	        		list1.add(m.group());
	        	
	        	}
	        	else if(c>=1){
	        	nextRow = line.split(",",-1);
	        
	        	System.out.print(nextRow[list.indexOf("DATE")]+"\t");
	        	System.out.print(nextRow[list.indexOf("TRX/ORDERNUMBER")]+"\t");
	        	System.out.print(nextRow[list.indexOf("VENDORNAME")]+"\t");
	        	System.out.print(nextRow[list.indexOf("VENDORNUMBER")]+"\t");
	        	System.out.print(nextRow[list.indexOf("BILLBACKDATE")]+"\t");
	        	System.out.print(nextRow[list.indexOf("APINVOICENUMBER")]+"\t");
	        	System.out.print(nextRow[list.indexOf("BILLBACKSOURCE")]+"\t");
	        	System.out.print(nextRow[list.indexOf("BILLBACKREASON")]+"\t");
	        	System.out.print(nextRow[list.indexOf("OFFERCODE")]+"\t");
	        	System.out.print(nextRow[list.indexOf("CUSTOMERNAME")]+"\t");
	        	System.out.print(nextRow[list.indexOf("ACCOUNTNUMBER")]+"\t");
	        	System.out.print(nextRow[list.indexOf("ACCOUNTNAME")]+"\t");
	        	System.out.print(nextRow[list.indexOf("UPC")]+"\t");
	        	System.out.print(nextRow[list.indexOf("ITEM#")]+"\t");
	        	System.out.print(nextRow[list.indexOf("BRAND")]+"\t");
	        	System.out.print(nextRow[list.indexOf("ITEMDESCRIPTION")]+"\t");
	        	System.out.print(nextRow[list.indexOf("PACKSIZE")]+"\t");
	        	System.out.print(nextRow[list.indexOf("UOM")]+"\t");
	        	System.out.print(nextRow[list.indexOf("QTY")]+"\t");
	        	System.out.print(nextRow[list.indexOf("LBS")]+"\t");
	        	System.out.print(nextRow[list.indexOf("CURRENCY")]+"\t");
	        	System.out.print(nextRow[list.indexOf("AMOUNT")]+"\t");
	        	
	        }
	        System.out.println();
	    }
	    }catch (IOException e) {
	        e.printStackTrace();
	    }
	}

}
