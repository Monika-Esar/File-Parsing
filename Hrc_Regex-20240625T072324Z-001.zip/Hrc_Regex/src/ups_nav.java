import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

public class ups_nav {

	public static void main(String[] args) throws Exception {
		//Creating a HttpClient object

		CloseableHttpClient httpclient = HttpClients.createDefault();
		
		//Creating a HttpGet object
		HttpGet httpget= new HttpGet("https://www.ups.com/WebTracking/track?loc=en_US&requester=ST/");
	    String data="";

		//Printing the method used
		System.out.println("Request Type: "+httpget.getMethod());
		
		//Executing the Get request
		HttpResponse httpresponse = httpclient.execute(httpget);
		for(Header header:httpresponse.getAllHeaders()) {
			System.out.println(header.getName().toString()+":"+header.getValue().toString());
			if(header.getValue().toString().startsWith("X-XSRF")) {
				data=header.getValue().toString();
			}
		}
		data=data.substring(data.indexOf("=")+1,data.indexOf(";"));
		System.out.println("DATA :"+data);
		 // Get HttpResponse Status
        System.out.println(httpresponse.getProtocolVersion());              // HTTP/1.1
        System.out.println(httpresponse.getStatusLine().getStatusCode());   // 200
        System.out.println(httpresponse.getStatusLine().getReasonPhrase()); // OK
        System.out.println(httpresponse.getStatusLine().toString());        // HTTP/1.1 200 OK
		
      	@SuppressWarnings("resource")
		Scanner sc = new Scanner(httpresponse.getEntity().getContent());
		while(sc.hasNext()) {
			System.out.println(sc.nextLine());
		}
		HttpPost httppost = new HttpPost("https://www.ups.com/track/api/Track/GetStatus?loc=en_US");
		StringEntity params=new StringEntity("{Locale: \"en_US\",TrackingNumber:[\"1ZE842660315952871\"]}");
	
		httppost.addHeader("Content-Type"," application/json");
		httppost.addHeader("X-XSRF-TOKEN", data);
		
		httppost.setEntity(params);
		HttpResponse response = httpclient.execute(httppost);
		
		System.out.println("Request Type: "+httppost.getMethod());
		//Printing the status line
		System.out.println(response.getProtocolVersion());              
        System.out.println(response.getStatusLine().getStatusCode());   
        System.out.println(response.getStatusLine().getReasonPhrase()); // OK
        System.out.println(response.getStatusLine().toString());        // HTTP/1.1 200 OK

		HttpEntity entity = response.getEntity();
        if (entity != null) {
            // return it as a String
            String result = EntityUtils.toString(entity);
            System.out.println(result);
        }
       
	}	
}


